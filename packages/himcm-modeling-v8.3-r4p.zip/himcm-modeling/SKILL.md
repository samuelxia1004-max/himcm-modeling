---
name: himcm-modeling
description: "HiMCM 完整建模工作流：读题选题、独立构思、真实数据分析、求解与反证、独立评审返修、英文论文和合规 PDF。适用于完整赛题、旧题训练、已有方案和论文；提供证据门槛与0–1质量评分协议。"
---

# HiMCM mathematical modeling · v8.3 candidate

把完整题面和附件推进为数学合理、逐问有实质答案、可复算且易读的英文作品。以 O/F 作品作参照；内部质量分、机械检查和官方奖项分别报告。当前候选状态查 `validation/v83/current-evidence.json`；继承的 v8/v8.1 和更早证据仅为历史，不认证本候选。v8.1-r3 的实际失败及 v8.2-r3 的历史页数计入反例保留，本候选须重新独审与完整整题前向，不声称稳定 0.98。

## 开始、恢复与权限

全权完成或继续的请求即授权连续构思、计算、修复和交付，不逐步询问。先读完整原题和全部官方附件，确认赛前训练、旧题复盘或当届比赛。初始化或恢复：

```bash
python /path/to/himcm-modeling/scripts/init_project.py PROJECT --year YEAR --problem A
```

`PROJECT_CONTEXT.md` 记录题目/输入版本、总预算和截止时点、已完成的实质答案、当前结果、待解决问题及下一动作。项目相对路径和 SHA-256 绑定输入、模型、参数、代码、结果、文稿、评审。只在项目及其 scratch 内生成文件；不删除既有资料，修订与归档保留版本。外部提交另需用户授权。

## 时间内形成完整作品

开始时按风险分配预算，预留至少最后四分之一用于验证、写作和最终核查。约一半时间应已有全部子问的稿件骨架与可用基线；约四分之三时运行第一次交付检查。扩展模型必须具体修复基线失败或回答额外必答任务，否则优先完成基线的证据链。

独立评审默认最多两次完整审阅加一次最终短复验，均计入原预算。第一轮优先核查影响主要答案的错误；第二轮核查修复及当前全文；最终短复验也必须另开全新上下文，逐项确认原问题和最终 PDF 哈希；不能延续前轮评审会话后声明 fresh_session: yes。阻塞问题仍在时，收缩/撤回对应结论并复验该处置；时间不足则交付明确的 PARTIAL。达到轮数上限不自动关闭问题。不要为了固定页数、模型数或审稿意见数量无限扩写。

## 解题主线

1. **逐问合同与选题。** 每条要求写成对象、输入、输出、成功标准、约束、验证方法和论文位置，登记 `artifacts/gate.json` 的 requirements。按数据可得性、可解释性、可完成性及验证机会比较 A/B，选择能闭环全部任务的路线。读 [problem-to-model.md](references/problem-to-model.md)。
2. **独立构思。** 看同题作品之前保存 `artifacts/independent_ideas.md`。从守恒、尺度、空间、时间链、随机性、排序和资源结构寻找自然表示；先构造最便宜的基线。路线有实际选择时，展开至少三个机制或表示不同的候选，给公式骨架、必要数据、能改变选择的判别测试及失败条件；有唯一自然解析结构时说明理由，不凑模型。GA/PSO 等不同求解器不算不同机制。选出能闭合任务且数据支持的主线。按需读 [award-thinking.md](references/award-thinking.md)、[model-atlas.md](references/model-atlas.md)。
3. **原始数据到决策。** 按 [data-analysis-playbook.md](references/data-analysis-playbook.md) 执行原始版本→实体/单位/时空口径/缺失审计→探索→处理→计算→验证→决策。题给地图和表格必须实质使用；核对下载内容真实类型，保留转换、误差和新分母。来源日志用唯一ID和精确Dataset名称标识数据集；外部检验的source_ids逐一对应该ID，data_source与其Dataset名称完全一致，不能靠“city/年份”等词重合认定同一数据。每个重要参数标 observed / attachment / external / estimated / assumed，记录数值、范围、用途、来源、访问日期和适用时段。不能用合成数据冒充附件或实测。
   在投入大批仿真或优化前，实际重建一条能改变建议的 `原始事实或明示价值判断→变换→模型输入→决策`。观测输入有来源、单位和口径；规范输入有定义、理由及代表谁的偏好，不假称专家测量。只有假设评分时，选择可支持的主张、条件方案或待区分集合；重复扰动不能补足现实证据。细则见上述参考§4。
4. **数学合同与求解。** 固定变量、单位、可用信息、目标/并列规则、硬约束、假设及理由、评价器、误差精度和停止条件。先手算/解析小例，再基线和主求解。优化输出独立复算可行性与目标；化简须保留全部声称的目标与合法边界。随机方法报告重复波动；含重尾或非线性风险的期望目标先检查必要矩存在性，有限次模拟不能证明期望有限。涉及未来输入、排队、地图拓扑、服务事件、尾部风险或分母转换时按需读[合同扩展](references/model-contract-extensions.md)。排名/准入、服务链或比较读 [decision-contracts.md](references/decision-contracts.md)。主要结果的决定性输入、公式、参数/随机生成器和中间量应能从比赛允许的报告内容回查，不能只指向未提交代码。
5. **按主张验证。** 摘要主张登记 claims，事前为各主张登记能推翻它的检验。预测/经验效应用未参与拟合、阈值、权重和选择的真实数据，并与相同信息、样本、约束、时窗和预算的朴素基线比较；看过结果再改规则，该数据即为开发集。`external_check` 改名不能恢复独立性。优化用独立计算、精确小例/界与现行或简单策略对照；机理、规范和偏好主张检查量纲、守恒、极限、反例及决策翻转点。没有独立数据就明确收缩为未经实证的条件结论，在正文给出限定摘录。失败检验须修复后用新证据检验、收缩范围或撤回；模型输给基线应如实说明，选基线或解释新增回答。计数/年度总量不替代时长/极端风险。读 [validation-review.md](references/validation-review.md)。
6. **解释与实施。** 从数值推出具体选择、成立范围、翻转阈值和回退方案。按题意说明执行者、时间、成本、资源约束、风险、利益相关方、公平性与监测更新；不适用项简述理由。因子敏感不等于可控或值得优先干预。

## 年份、来源和学习库

开始时核验当届 COMAP 原题、Instructions 和 AI Policy；[contest-rules.md](references/contest-rules.md) 的快照需刷新。2026 官方上限为摘要在内25页，英文至少12pt，AI报告追加且不计页数；匿名、队号/页码和文件大小按当届要求检查。没有官方18页下限，18–25页仅是深度诊断参考；完整短文按实质评审，不以填页替代证据。参考/附录是否计页按目标年份的规则和明确锚点，不臆造豁免。 `pdf.main_pages` 仅表示 AI 报告前正文页数，不等于当年计入上限的页数。默认把 AI 页计入；只有目标年份原文明确豁免时，才登记 `rules.ai_report_excluded_from_main_limit: true` 及 `rules.ai_report_exclusion_rule_quote`，并实际核对物理总页数、正文页数和计入页数。

历史训练先明确是“当年信息重演”还是“现代资料复盘”。前者输入/校准/验证限截至比赛时已可得的资料，分别保存原始发布日期、数据覆盖期、所用修订版和访问日期；版本核查读 [source-version-check.md](references/source-version-check.md)，检查 PDF 原文修订说明并逐字段对照实际使用内容；metadata 和目录名中的年份仅为线索，不能证明该版在历史赛期可得；确切截止日未知则记录不确定范围，不把1月1日当真实赛期。后者允许现代资料但明确其角色，不把结果冒称当年可实现表现。比赛期间遵守禁止队外人类协助、调查访谈及公开传播赛题/方案的规则，真实披露 AI。

学习库包括本机技能整合、Nature 方法链和 O/F 作品经验，按机制查阅，非必引清单。只摘要阅读的文献不能支持具体方法或定量断言。参考 [source-integration.md](references/source-integration.md)、[nature-method-transfer.md](references/nature-method-transfer.md)、[o-paper-practices.md](references/o-paper-practices.md)；v6结构建议 [o-paper-practices-v6.md](references/o-paper-practices-v6.md) 按任务触发。新地区迁移、流程图、耦合、区间等只有实质用途才增加。

## 论文、独立评审与交付

按“任务→假设与理由→数学定义→数据→求解→结果→验证→决策”组织；Summary Sheet 最后写且完整落在第一页，含核心选择、重要数字/单位、验证结果和建议。信函/文章按原题受众完成。图表、主文、摘要和非技术建议共享当前结果证书。自然英文终审整合 academic-humanization、humanizer、stop-slop、anti-defensive-writing、no-negative-echo、humanize：冻结数学事实、术语、数字、单位、引用和真实限定，删除空话重复，编辑后核对科学语义。细则见 [paper-and-style.md](references/paper-and-style.md)。

评审用全新上下文，给原题、全部附件、当前 PDF 及所需复算证据；后续加原问题表。可用 Codex 新会话或独立子代理；平台支持时显式禁用历史继承（本工具为 `fork_turns: none`），只传允许输入。新代理ID本身不证明隔离，延续会话不算fresh。记录实际派发设置、模型、会话、阅读/看图范围、复算和输入哈希；不能把自写记录当独立性证明。只列真实问题，不设“五条意见”配额。每项有稳定编号、位置、证据、Severity、影响、最小修复、当前状态和复验条件。最终审阅须针对实际最终 PDF，对所有已有编号重新给 verdict；短验也逐ID确认，不能用全局结论代替。

使用 `assets/critic_prompt_template.md` 和 `assets/critic_template.md`。原始评语的问题用显式 Issues/Findings 区或 Severity/Location/Minimal fix/Verdict 字段表达；任务覆盖、已读页、参考文献和复算清单放在各自区域。原始非数字编号是不可拆解的稳定 ID，按模板显式声明每轮 raw ID 到汇总编号的映射，不按 C1-01 等后缀猜号。高严重度问题未修复不得用 WONTFIX 放行；撤回/收缩后获得最终版本 FIXED 证明才闭环。FIXED_UNREVIEWED 保持 INCOMPLETE。没有阻塞问题可由评审原始输出与汇总共同写 `Review verdict: NO_BLOCKING_ISSUES`，不制造问题。

```bash
python /path/to/himcm-modeling/scripts/check_gate.py PROJECT --pdf final/TEAM.pdf --output PROJECT/artifacts/review/gate_result.json
python /path/to/himcm-modeling/scripts/check_pdf.py PROJECT/final/TEAM.pdf --team TEAM --main-pages N --max-main-pages CAP
```

GATE_PASS 仅说明已登记证据的机械一致性，不能单独判定论文完成、数学正确或获奖。GATE_FAIL/INCOMPLETE 保留缺口；还须逐问实质复核、关键数值替代路径复算、最终PDF全页实际查看、格式/匿名与真实AI披露检查。AI核查实际定位正文使用处、参考文献条目与追加报告，按目标年份原文判断，不能只见到报告标题就算完整，也不把政策示例升级为未写明的硬性要求。只有这些实际执行且核心阻塞均闭环，才能称科学交付完成。缺失输入、检验、最终渲染或核心修复则准确标 PARTIAL，并保存仍有价值的成果。

交付英文PDF、可编辑稿、本地代码/数据、来源/引用账本、结果证书、图表源码、评审/修复记录和复现说明；比赛实际提交按规则，内部支持包单独保存。

## 0–1评分与持续改进

用户要求评估水平或改进技能时，读 [evaluation-protocol.md](references/evaluation-protocol.md)。从真实失效提炼通用修复，冻结版本后独立前向验证；训练/开发/测试题、首稿/辅助返修、完整整题/构思探针分开。学习过解答的旧题不能重新标为从未见过；清理参考文件只能去除显性泄漏，不能清除模型预训练记忆。

0–1分呈现当前作品的证据质量，附样本、逐项证据和未核查范围；官方O/F只用可核验标签作参照，不给“必获O”或虚构获奖概率。均值达到0.98不自动叫稳定；报告最低分、逐题分布、重复运行和跨评委差异，保留失败。复杂修订用冻结技能、原题和附件在独立新上下文完整求解，再从原始输入核验。
