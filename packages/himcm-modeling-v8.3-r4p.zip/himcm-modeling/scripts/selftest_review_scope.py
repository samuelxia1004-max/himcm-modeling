#!/usr/bin/env python3
"""v8.2 live raw-review scope controls. Implementation tests, not independent review.
Run with Python 3.13: selftest_review_scope.py NEW_WORKDIR [--audit-inputs AUDITDIR]
The optional frozen audit inputs are replayed unchanged with explicit legacy-ambiguity expectations.
"""
import argparse, hashlib, json, sys
from pathlib import Path
import check_gate as cg
import selftest_gate as fx


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('workdir', type=Path)
    ap.add_argument('--audit-inputs', type=Path)
    ap.add_argument('--noissues-audit-inputs', type=Path)
    ap.add_argument('--mixed-audit-inputs', type=Path)
    args = ap.parse_args(); w = args.workdir.resolve()
    w.mkdir(parents=True, exist_ok=False)
    results = []
    def sha(data): return hashlib.sha256(data).hexdigest()
    def parser(name, text, expected, required=(), noerrors=True):
        errors = []; actual = cg.parse_raw_issues(text, errors)
        ok = actual == expected and all(any(s in e for e in errors) for s in required) and (not noerrors or not errors)
        results.append(dict(case=name, kind='parser', ok=ok, input_sha256=sha(text.encode()), expected=expected, actual=actual, errors=errors, required=required))
        (w/(name+'.md')).write_text(text)
        print(('OK  ' if ok else 'BAD ') + name)
    H = 'pdf_sha256: '+'0'*64+'\nfresh_session: yes\ninherited_parent_context: no\n'
    I = '## Issues\n### 1. Defect\nSeverity: high\nLocation: p3\nVerdict: NOT FIXED\n'
    for key in ('review_kind', 'session_mode', 'review-mode', 'phase2', 'reviewer'):
        parser('explicit_metadata_'+key, H+'## Review metadata\n'+key+': independent\n\nReview verdict: NOT FIXED\n'+I, [('1','NOT FIXED')])
    parser('explicit_metadata_bare_global_rejected', H+'## Review metadata\nsession_mode: independent\nVerdict: NOT FIXED\n'+I, [('1','NOT FIXED')], ('CRITIC_RAW_AMBIGUOUS_SCOPE',),False)
    parser('opaque_same_bytes_ambiguous', H+'review_kind: independent\nVerdict: NOT FIXED\n', [('review_kind',None)], ('CRITIC_RAW_AMBIGUOUS_SCOPE',),False)
    parser('opaque_colon_verdict_only_ambiguous', H+'C1-06: denominator wrong\nVerdict: NOT FIXED\n', [('C1-06',None)], ('CRITIC_RAW_AMBIGUOUS_SCOPE',),False)
    for ident in ('review_kind','C1-06','C6'):
        parser('genuine_bare_opaque_'+ident, H+ident+': denominator wrong\nSeverity: high\nLocation: p3\nVerdict: NOT FIXED\n', [(ident,'NOT FIXED')])
        parser('explicit_opaque_only_verdict_'+ident, H+'## Issues\n'+ident+': denominator wrong\nVerdict: NOT FIXED\n', [(ident,'NOT FIXED')])
    parser('opaque_space_title',H+'C6 denominator wrong\nVerdict: NOT FIXED\n',[('C6','NOT FIXED')])
    parser('incomplete_findings',H+'## Findings\n### review_kind\nMissing evidence\n',[('review_kind',None)])
    parser('nested_findings',H+'## Open issues\n### Numerical defects\n6. Missing evidence\n',[('6',None)])
    parser('nested_heading_conflict',H+'2. Result | Verdict: FIXED\n### Recheck details\nVerdict: NOT FIXED\n',[('2',None)],('CRITIC_RAW_VERDICT_COUNT',),False)
    parser('outside_child_fields',H+'6. Result\n### Details\nSeverity: high\nLocation: p3\n',[('6',None)])
    parser('pipe_and_multiline_fields',H+'## Issues\n1. Location: p3 | Severity: high\n- Verdict:\n\nFIXED\n',[('1','FIXED')])
    parser('emphasized_fields',H+'## Issues\n1. **Location:** p3 | **Verdict:** **FIXED**\n',[('1','FIXED')])
    parser('fields_must_be_declarations',H+'## Issues\n1. Result\nOrdinary prose mentions Verdict: FIXED\n',[('1',None)])
    parser('global_never_supplies_issue_verdict',H+'## Issues\n1. Result\nSeverity: medium\nReview verdict: FIXED\n',[('1',None)])
    for name, sample in (
        ('fence','```text\nC6: Example | Verdict: FIXED\n```'),
        ('comment','<!-- C6: Example\nVerdict: FIXED -->'),
        ('inline','`C6: Example | Verdict: FIXED`'),
        ('quote','> C6: Example\n> Verdict: FIXED'),
        ('indented','    C6: Example\n    Verdict: FIXED')):
        parser(name+'_issue_example_inert',H+'## Findings\n'+sample+'\n',[])
        parser(name+'_cannot_supply_verdict',H+'## Issues\n2. Result\n'+sample+'\n',[('2',None)])
    parser('live_after_examples',H+'## Issues\n```text\n<!--\n```\n<!-- C6: example -->\n> C7: example\n\nC8: real issue\nSeverity: high\nVerdict: NOT FIXED\n',[('C8','NOT FIXED')])
    parser('live_after_inline_comment_literal',H+'## Issues\nExample: `<!--`\nC8: real issue\nSeverity: high\nVerdict: NOT FIXED\n',[('C8','NOT FIXED')])
    parser('live_after_quote_comment_literal',H+'## Issues\n> <!--\n\nC8: real issue\nSeverity: high\nVerdict: NOT FIXED\n',[('C8','NOT FIXED')])
    parser('real_comment_closes_before_inline_tick',H+'## Issues\n<!-- Example `text -->\nC8: real issue\nSeverity: high\nVerdict: NOT FIXED\n',[('C8','NOT FIXED')])
    parser('unclosed_inline_fail_closed',H+'## Issues\n2. Result\nExample: `Verdict: FIXED\n',[('2',None)],('CRITIC_RAW_AMBIGUOUS_SCOPE',),False)
    parser('lazy_quote_fail_closed',H+'## Issues\n2. Result\n> Example\nVerdict: FIXED\n',[('2',None)],('CRITIC_RAW_AMBIGUOUS_SCOPE',),False)
    parser('unsupported_id_fields_rejected',H+'## Findings\n### CRITICAL\nSeverity: high\n',[],('CRITIC_RAW_UNASSIGNED_ISSUE_FIELDS',),False)
    parser('metadata_numeric_issue_fields_rejected',H+'## Review metadata\n1. Severity: high\n'+I,[('1','NOT FIXED')],('CRITIC_RAW_AMBIGUOUS_SCOPE',),False)

    def gate(name, setup, want, must=None):
        d,g=fx.make(w/'gate'/name); setup(d,g); fx.save(d,g); code,out=fx.run(d)
        msgs='\n'.join(out.get('fail',[])+out.get('incomplete',[]))
        ok=code==want and (not must or must in msgs)
        results.append(dict(case=name,kind='gate',ok=ok,expected_exit=want,actual_exit=code,required=must,result=out))
        print(('OK  ' if ok else 'BAD ') + name+f': exit {code} (want {want})')
    def replace_final(d, value):
        p=d/'artifacts/review/r2.md';p.write_text(p.read_text().replace('2. restated | Verdict: FIXED | Evidence: p2 | none',value))
    def add_initial(d, text):
        p=d/'artifacts/review/r1.md';p.write_text(p.read_text()+'\n'+text)
    def metadata(d,g, explicit=True):
        p=d/'artifacts/review/r1.md'; lines=p.read_text().splitlines()
        body=('## Review metadata\nsession_mode: independent\nReview verdict: NOT FIXED\n## Issues\n' if explicit else 'session_mode: independent\nVerdict: NOT FIXED\n')
        p.write_text(lines[0]+'\n'+body+'\n'.join(lines[1:])+'\n')
    gate('baseline',lambda d,g:None,0)
    gate('new_metadata_no_false_issue',metadata,0)
    gate('legacy_metadata_global_ambiguous',lambda d,g:metadata(d,g,False),1,'CRITIC_RAW_AMBIGUOUS_SCOPE')
    for name, sample in (
        ('fence','```text\nVerdict: FIXED\n```'),('comment','<!--\nVerdict: FIXED\n-->'),
        ('inline','Example: `Verdict: FIXED`'),('quote','> Verdict: FIXED')):
        gate(name+'_missing_real_final',lambda d,g,s=sample:replace_final(d,'2. restated | Evidence: p2\n'+s),2,'CRITIC_FINAL_ISSUE_UNVERIFIED')
    gate('global_missing_real_final',lambda d,g:replace_final(d,'2. restated | Evidence: p2\nReview verdict: NO_BLOCKING_ISSUES'),2,'CRITIC_FINAL_ISSUE_UNVERIFIED')
    gate('nested_verdict_conflict',lambda d,g:replace_final(d,'2. restated | Verdict: FIXED\n### Details\nVerdict: NOT FIXED'),1,'CRITIC_RAW_VERDICT_COUNT')
    gate('genuine_opaque_high_unclosed',lambda d,g:add_initial(d,'review_kind: denominator wrong\nSeverity: high\nLocation: p2'),1,'CRITIC_RAW_ISSUES_NOT_CLOSED')
    gate('new_incomplete_findings',lambda d,g:add_initial(d,'## Findings\nC6: Missing evidence'),1,'CRITIC_RAW_ISSUES_NOT_CLOSED')
    gate('live_issue_after_fenced_comment',lambda d,g:add_initial(d,'## Findings\n```text\n<!--\n```\nC6: Missing evidence'),1,'CRITIC_RAW_ISSUES_NOT_CLOSED')
    def high(d,g):
        p=d/'artifacts/review/critic.md';p.write_text(p.read_text().replace('2. Issue 2 about claim C1. Severity: medium\nStatus: FIXED (verified round 2)','2. Issue 2 about claim C1. Severity: high\nStatus: WONTFIX deadline'))
    gate('high_wontfix',high,1,'CRITIC_HIGH_WONTFIX')
    gate('latest_not_fixed',lambda d,g:fx.write_critic(d,contra=True),1,'CRITIC_CONTRADICTION')
    gate('short_final_still_needs_all_prior',lambda d,g:fx.write_critic(d,round3={1:'FIXED'}),2,'CRITIC_FINAL_ISSUE_UNVERIFIED')
    def illegal_metadata(d,g):
        add_initial(d,'## Review metadata\nSeverity: high\n')
    gate('metadata_cannot_hide_fields',illegal_metadata,1,'CRITIC_RAW_AMBIGUOUS_SCOPE')

    # r2: the zero-issue path needs an authoritative result on both sides.
    decl = 'Review verdict: NO_BLOCKING_ISSUES\n'
    def noissues(d,g,raw_decl=decl,closure_decl=decl):
        digest=fx.sha(d/'final/TEAM.pdf')
        (d/'artifacts/review/final.md').write_text('pdf_sha256: '+digest+'\n## Review metadata\nfresh_session: yes\ninherited_parent_context: no\n\n'+raw_decl)
        (d/'artifacts/review/critic.md').write_text('Critic: independent fictional reviewer\nRound: 1 | critic: independent | fresh_session: yes | pdf_sha256: '+digest+' | raw: artifacts/review/final.md\n'+closure_decl)
    gate('noissues_live_positive',noissues,0)
    gate('noissues_missing_raw',lambda d,g:noissues(d,g,raw_decl=''),2,'CRITIC_NO_ISSUE_VERDICT_NOT_IN_RAW')
    gate('noissues_missing_closure',lambda d,g:noissues(d,g,closure_decl=''),2,'CRITIC: list actual issues')
    examples = {
        'fence':'```text\n'+decl+'```\n',
        'comment':'<!--\n'+decl+'-->\n',
        'inline':'`Review verdict: NO_BLOCKING_ISSUES`\n',
        'quote':'> Review verdict: NO_BLOCKING_ISSUES\n\n',
        'indented':'    Review verdict: NO_BLOCKING_ISSUES\n',
        'prose':'The reviewer mentioned Review verdict: NO_BLOCKING_ISSUES as a possible result.\n',
    }
    for side in ('raw','closure'):
        def setup(value,side=side):
            return lambda d,g:noissues(d,g,**{side+'_decl':value})
        missing='CRITIC_NO_ISSUE_VERDICT_NOT_IN_RAW' if side=='raw' else 'CRITIC: list actual issues'
        for kind,value in examples.items():
            gate('noissues_'+side+'_'+kind+'_cannot_authorize',setup(value),2,missing)
        for kind,value in {
            'duplicate':decl+decl,
            'conflict':decl+'Review verdict: NOT FIXED\n',
            'reverse_conflict':'Review verdict: NOT FIXED\n'+decl,
            'pipe_conflict':'Review verdict: NO_BLOCKING_ISSUES | Review verdict: NOT FIXED\n',
            'invalid_second':decl+'Review verdict: UNKNOWN\n',
        }.items():
            gate('noissues_'+side+'_'+kind,setup(value),1,'CRITIC_REVIEW_VERDICT_COUNT')
        # Example conclusions cannot create duplicates or override a live result.
        mixed=''.join(examples.values())+decl
        gate('noissues_'+side+'_mixed_live_examples',setup(mixed),0)
        gate('noissues_'+side+'_live_negative_example_positive',setup('Review verdict: NOT FIXED\n'+examples['fence']+examples['comment']),2,missing)
        gate('noissues_'+side+'_lazy_quote_ambiguous',setup('> Example\n'+decl),1,'CRITIC_RAW_AMBIGUOUS_SCOPE')
        gate('noissues_'+side+'_unclosed_inline_ambiguous',setup('`'+decl),1,'CRITIC_RAW_AMBIGUOUS_SCOPE')
        quoted_negative='> Review verdict: NOT FIXED\n\n'+decl
        gate('noissues_'+side+'_quoted_negative_then_live',setup(quoted_negative),0)
        for kind,value in {
            'bullet':'- '+decl,
            'pipe':'Result kind: overall | '+decl,
            'multiline':'Review verdict:\nNO_BLOCKING_ISSUES\n',
            'emphasis':'**Review verdict:** **NO_BLOCKING_ISSUES**\n',
        }.items():
            gate('noissues_'+side+'_live_'+kind,setup(value),0)
        gate('noissues_'+side+'_trailing_prose_invalid',setup('Review verdict: NO_BLOCKING_ISSUES was only an example\n'),2,missing)
        gate('noissues_'+side+'_fixed_is_not_noissues',setup('Review verdict: FIXED\n'),2,missing)

    for ident in ('1.','C6:'):
        gate('noissues_issue_row_global_cannot_hide_'+ident.replace(':','colon').replace('.','dot'),lambda d,g,ident=ident:noissues(d,g,raw_decl='## Issues\n'+ident+' Location: p3 | Severity: high | Review verdict: NO_BLOCKING_ISSUES\n'),1,'CRITIC_RAW_ISSUES_NOT_CLOSED')

    # r3: global results cannot suppress adjacent live issue-control cells.
    control_values={'Severity':'high','Location':'p3','Minimal fix':'correct denominator','Verdict':'NOT FIXED'}
    for side in ('raw','closure'):
        def setup_mixed(value,side=side):
            return lambda d,g:noissues(d,g,**{side+'_decl':value})
        for control,value in control_values.items():
            token=control.lower().replace(' ','_')
            cell=control+': '+value
            for scope in ('Review metadata','Issues','Review notes'):
                row='## '+scope+'\nReview verdict: NO_BLOCKING_ISSUES | '+cell+'\n'
                gate('mixed_'+side+'_'+token+'_'+scope.replace(' ','_'),setup_mixed(row),1,'CRITIC_REVIEW_MIXED_FIELDS')
            gate('mixed_'+side+'_'+token+'_reversed',setup_mixed(cell+' | '+decl),1,'CRITIC_REVIEW_MIXED_FIELDS')
            gate('mixed_'+side+'_'+token+'_inline_example_control',setup_mixed('Review verdict: NO_BLOCKING_ISSUES | `'+cell+'`\n'),0)
        example_row='Review verdict: NO_BLOCKING_ISSUES | '+' | '.join(k+': '+v for k,v in control_values.items())+'\n'
        gate('mixed_'+side+'_fence_example_then_live',setup_mixed('```text\n'+example_row+'```\n'+decl),0)
        gate('mixed_'+side+'_comment_example_then_live',setup_mixed('<!--\n'+example_row+'-->\n'+decl),0)
        gate('mixed_'+side+'_quote_example_then_live',setup_mixed('> '+example_row+'\n'+decl),0)
        gate('mixed_'+side+'_simple_valid_global',setup_mixed(decl),0)
    for control,value in control_values.items():
        token=control.lower().replace(' ','_')
        gate('mixed_after_real_issue_'+token,lambda d,g,control=control,value=value:replace_final(d,'2. restated | Verdict: FIXED | Evidence: p2 | none\nReview verdict: NO_BLOCKING_ISSUES | '+control+': '+value),1,'CRITIC_REVIEW_MIXED_FIELDS')

    if args.mixed_audit_inputs:
        audit=args.mixed_audit_inputs.resolve()
        names={'unassigned_same_global_row','metadata_same_global_row','issue_verdict_on_global_row'}
        originals=[x for x in json.loads((audit/'results.json').read_text()) if x['case'] in names]
        if len(originals)!=3: raise ValueError('Expected all three frozen mixed-row counterexamples')
        for original in originals:
            d=audit/'inputs'/original['case']
            before={str(f.relative_to(d)):fx.sha(f) for f in d.rglob('*') if f.is_file()}
            code,out=fx.run(d)
            after={str(f.relative_to(d)):fx.sha(f) for f in d.rglob('*') if f.is_file()}
            msgs='\n'.join(out.get('fail',[])+out.get('incomplete',[]))
            must='CRITIC_REVIEW_MIXED_FIELDS'
            ok=code==original['expected_exit']==1 and before==after==original['input_sha256'] and must in msgs
            results.append(dict(case='r2_frozen_'+original['case'],kind='mixed_frozen_replay',ok=ok,original_actual_exit=original['actual_exit'],original_required=original.get('required'),expected_exit=original['expected_exit'],actual_exit=code,input_sha256=before,inputs_unchanged=before==after,result=out,required=must))
            print(('OK  ' if ok else 'BAD ')+'r2_frozen_'+original['case']+f': exit {code}')

    if args.noissues_audit_inputs:
        audit=args.noissues_audit_inputs.resolve()
        for original in json.loads((audit/'minimal-results.json').read_text()):
            d=audit/'minimal'/original['case']
            before={str(f.relative_to(d)):fx.sha(f) for f in d.rglob('*') if f.is_file() and f.name not in ('stdout.json','stderr.txt')}
            code,out=fx.run(d)
            after={str(f.relative_to(d)):fx.sha(f) for f in d.rglob('*') if f.is_file() and f.name not in ('stdout.json','stderr.txt')}
            name=original['case'];must=None
            if name in ('missing_negative','final_fence','final_comment'): must='CRITIC_NO_ISSUE_VERDICT_NOT_IN_RAW'
            if name in ('summary_fence','summary_comment'): must='CRITIC: list actual issues'
            msgs='\n'.join(out.get('fail',[])+out.get('incomplete',[]))
            ok=code==original['expected_exit'] and before==after==original['input_sha256'] and (not must or must in msgs)
            results.append(dict(case='r1_frozen_'+name,kind='noissues_frozen_replay',ok=ok,original_actual_exit=original['actual_exit'],expected_exit=original['expected_exit'],actual_exit=code,input_sha256=before,inputs_unchanged=before==after,result=out,required=must))
            print(('OK  ' if ok else 'BAD ')+'r1_frozen_'+name+f': exit {code}')

    if args.audit_inputs:
        audit=args.audit_inputs.resolve()
        # Frozen inputs requiring a changed result are explicitly named here.
        ambiguous={'actual_frozen_raw','metadata_review_kind','metadata_generic_underscore','metadata_hyphen_key','metadata_separated_global','metadata_alphanumeric_key','metadata_plain_alpha_key','opaque_bare_colon_id'}
        for old in json.loads((audit/'parser_results.json').read_text()):
            name=old['case']; data=(audit/old['input']).read_bytes(); text=data.decode()
            errs=[];got=cg.parse_raw_issues(text,errs)
            if name in ambiguous:
                # Retain opaque IDs without treating an ambiguous Verdict as authority.
                retained = {'actual_frozen_raw':'review_kind', 'metadata_review_kind':'review_kind',
                            'metadata_generic_underscore':'session_mode', 'metadata_hyphen_key':'review-mode',
                            'metadata_separated_global':'session_mode', 'metadata_alphanumeric_key':'phase2',
                            'metadata_plain_alpha_key':'inherited_parent_context', 'opaque_bare_colon_id':'C1-06'}[name]
                expected = [(retained,None)] + ([] if name=='opaque_bare_colon_id' else [tuple(x) for x in old['expected_issues']])
                ok=got==expected and any('CRITIC_RAW_AMBIGUOUS_SCOPE' in e for e in errs)
            else:
                ok=[list(x) for x in got]==old['expected_issues'] and all(any(s in e for e in errs) for s in old['expected_error_substrings']) and (bool(old['expected_error_substrings']) or not errs)
            results.append(dict(case='audit_'+name,kind='frozen_replay',ok=ok,input_sha256=sha(data),actual=got,errors=errs,reclassified_ambiguous=name in ambiguous,original_expected=old['expected_issues']))
            print(('OK  ' if ok else 'BAD ')+'audit_'+name)
        p=audit/'ambiguous_same_bytes.md'
        parser('audit_same_bytes',p.read_text(),[('review_kind',None)],('CRITIC_RAW_AMBIGUOUS_SCOPE',),False)
    (w/'results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
    good=sum(bool(r['ok']) for r in results)
    print(f'REVIEW SCOPE SELFTEST {"PASS" if good==len(results) else "FAIL"} ({good}/{len(results)} cases)')
    return 0 if good==len(results) else 1

if __name__=='__main__': sys.exit(main())
