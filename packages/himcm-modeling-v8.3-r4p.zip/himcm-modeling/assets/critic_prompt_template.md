# Critic prompts (copy into a NEW session each round; Codex CLI `codex exec` in a fresh run is the default critic)

## Round 1 (full critique)
You are an independent critic of a HiMCM paper. Read ONLY the files in this folder: the problem statement and attachments, and paper.pdf. Do not read anything else.
First run `shasum -a 256 paper.pdf` (or `sha256sum`) and write the line `pdf_sha256: <hex>` at the top of critic_out.md.
After the top SHA line, put fresh_session: yes, inherited_parent_context: no and any custom metadata under an explicit `## Review metadata` heading. Use `Review verdict:` for the whole-review conclusion; never use bare `Verdict:` for that conclusion. Metadata must not contain Severity, Location, Minimal fix or per-issue Verdict fields.
Place actual issue entries under an explicit `## Issues` or `## Findings` heading. Keep numbered task-coverage, pages-read, references and recomputation lists in separate sections. Keep IDs stable; if a named ID differs from the numeric closure ID, preserve it and declare the mapping in the closure file, without editing this raw output.
List the actual issues most likely to overturn conclusions; do not invent a quota of issues (untested headline claims, hold-out reuse, cutoff violations, unused attachments, summary stronger than evidence, numbers inconsistent with tables). Format per issue:
N. Location: | Evidence: | Severity: high/medium/low | Minimal fix:
End with: "Length verdict: <padding or substance?>". Do not modify or delete other files.

## Round 2+ (NEW context for every round, including the short final verification; the LAST round must read the FINAL PDF)
Independent critic, round K. Read ONLY: the problem files, previous_issues.md (earlier issues) and paper.pdf.
First write `pdf_sha256: <hex>` (from shasum -a 256 paper.pdf) at the top of critic_roundK.md. Then write `## Review metadata`, `fresh_session: yes` and `inherited_parent_context: no`; put any custom metadata there. Use `Review verdict:` for the overall conclusion. Start the issue list with `## Issues`; metadata cannot contain issue control fields.
For every earlier stable issue ID, including previously FIXED issues, write exactly one live issue entry with its own Verdict. A short final review has the same requirement; a global conclusion cannot replace any per-issue verdict. For numeric issue N write:
N. <restatement> | Verdict: FIXED or NOT FIXED | Evidence: <page/quote> | Remaining fix
Carry all earlier issue IDs into this final-PDF review even if previously fixed. Then list any NEW high-severity issues (same format as round 1, numbered after the last old issue). Do not modify or delete other files.

If no blocking issues exist, explicitly write `Review verdict: NO_BLOCKING_ISSUES`. Inspect all applicable tasks; the declaration is not proof of correctness. At most two full reviews plus one short final verification within the original budget. If a blocker remains, restrict/withdraw the affected claim and verify that disposition, or report PARTIAL.

A continuation of an earlier reviewer is not a fresh final verification. Start a new context and provide the bounded packet plus all earlier issues; retain failed/continuation review evidence.

Raw declaration contract (v8.2): put each issue field at the start of a line (optionally `- `), or at the start of a same-line pipe cell. `Verdict:` may have its FIXED/NOT FIXED value on the next live line. Fenced code, HTML comments, inline code and Markdown blockquotes are examples, not issue/field declarations. Keep live declarations outside them; put a blank line after a quote. Bare opaque `key: value` plus only `Verdict:` outside Issues/Findings is ambiguous and fails closed. Explicitly scoped existing numeric/opaque IDs remain supported. This contract governs newly generated raw output; never rewrite a frozen third-party raw report to make it pass.

For a zero-issue completion, both the closure summary and the final raw must contain exactly one live `Review verdict: NO_BLOCKING_ISSUES`. Code/comments/inline code/quotes/indented examples and ordinary prose mentions cannot authorize that result; duplicate or conflicting live Review verdict declarations fail.

Keep whole-review Review verdict declarations on rows containing no Severity, Location, Minimal fix or per-issue Verdict declaration cells. A live row mixing these scopes fails, including inside metadata or after an issue; an overall result cannot suppress adjacent issue controls. Global-only pipe rows remain supported.
